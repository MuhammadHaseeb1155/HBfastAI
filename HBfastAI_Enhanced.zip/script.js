// Theme toggle and simple loading indicator demo
document.addEventListener("DOMContentLoaded", function(){
  const btn = document.getElementById("theme-toggle");
  btn.addEventListener("click", ()=>{
    document.body.classList.toggle("light");
    btn.textContent = document.body.classList.contains("light") ? "🌙" : "☀️";
  });
});