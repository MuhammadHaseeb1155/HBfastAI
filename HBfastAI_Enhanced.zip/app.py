import gradio as gr
from diffusers import StableDiffusionPipeline
import torch
from moviepy.editor import ImageClip, concatenate_videoclips
from transformers import pipeline
from PIL import Image, ImageFilter, ImageEnhance
import tempfile, os

# ---- Models ----
# Stable Diffusion pipeline (may be large; Spaces may use CPU)
MODEL_ID = "runwayml/stable-diffusion-v1-5"
try:
    pipe = StableDiffusionPipeline.from_pretrained(MODEL_ID, torch_dtype=torch.float16)
    pipe = pipe.to("cuda") if torch.cuda.is_available() else pipe.to("cpu")
except Exception as e:
    pipe = None
    print("Failed to load SD pipeline:", e)

# Small chat model (placeholder)
try:
    chatbot_pipe = pipeline("text-generation", model="gpt2")
except Exception as e:
    chatbot_pipe = None
    print("Failed to load chat pipeline:", e)

# ---- Utilities ----
def generate_image(prompt):
    if pipe is None:
        return None
    image = pipe(prompt, guidance_scale=7.5, num_inference_steps=20).images[0]
    return image

def image_to_5s_video(image):
    # create a 5s video from a single image
    tmpdir = tempfile.mkdtemp()
    out = os.path.join(tmpdir, "output.mp4")
    clip = ImageClip(image).set_duration(5)
    clip.write_videofile(out, fps=24, codec="libx264", audio=False, verbose=False, logger=None)
    return out

def text_to_30s_video(prompt):
    # generate a single image and stretch to 30s
    if pipe is None:
        return None
    img = pipe(prompt, guidance_scale=7.0, num_inference_steps=18).images[0]
    tmpdir = tempfile.mkdtemp()
    out = os.path.join(tmpdir, "slideshow.mp4")
    clip = ImageClip(img).set_duration(30)
    clip.write_videofile(out, fps=24, codec="libx264", audio=False, verbose=False, logger=None)
    return out

# Simple upscale using PIL (not ML upscale)
def upscale_image(pil_img, scale=2):
    w,h = pil_img.size
    new = pil_img.resize((w*scale, h*scale), resample=Image.LANCZOS)
    return new

# Simple background removal: make white-ish pixels transparent (fast naive method)
def remove_background(pil_img, threshold=240):
    pil = pil_img.convert("RGBA")
    datas = pil.getdata()
    newData = []
    for item in datas:
        r,g,b,a = item
        if r>threshold and g>threshold and b>threshold:
            newData.append((255,255,255,0))
        else:
            newData.append(item)
    pil.putdata(newData)
    return pil

def images_to_gif(images, duration=500):
    tmpdir = tempfile.mkdtemp()
    out = os.path.join(tmpdir, "out.gif")
    pil_images = [img.convert("RGBA") for img in images]
    pil_images[0].save(out, save_all=True, append_images=pil_images[1:], duration=duration, loop=0)
    return out

def chat_reply(message):
    if chatbot_pipe is None:
        return "Chat model not available in this Space."
    resp = chatbot_pipe(message, max_length=100)[0]['generated_text']
    return resp

# ---- Gradio UI ----
with gr.Blocks(title="HBfast.ai — Free AI Tools", theme=None) as demo:
    gr.Markdown("<h1 style='text-align:center'>HBfast.ai</h1>")
    with gr.Row():
        with gr.Column(scale=2):
            gr.Markdown("**Create images, short videos, GIFs and chat with AI — free.**")
            gr.Markdown("**Tip:** Keep prompts short for faster results.")
        with gr.Column(scale=1):
            gr.Image(value="logo.svg", show_label=False)
    with gr.Tabs():
        with gr.TabItem("Image Generator"):
            prompt = gr.Textbox(label="Prompt", placeholder="a cute robot in a neon city")
            gen_btn = gr.Button("Generate Image")
            out_img = gr.Image()
            status = gr.Markdown("")
            def _gen(p):
                status.update("Generating image...")
                res = generate_image(p)
                status.update("Done." if res is not None else "Model not loaded.")
                return res
            gen_btn.click(_gen, inputs=prompt, outputs=out_img)

        with gr.TabItem("Image → 5s Video"):
            img_in = gr.Image(label="Upload image or use generated image", type="pil")
            vbtn = gr.Button("Create 5s Video")
            vout = gr.Video()
            vbtn.click(image_to_5s_video, inputs=img_in, outputs=vout)

        with gr.TabItem("Text → 30s Video"):
            tprompt = gr.Textbox(label="Enter video prompt (will create a 30s video)")
            tbtn = gr.Button("Generate 30s Video")
            tout = gr.Video()
            tbtn.click(text_to_30s_video, inputs=tprompt, outputs=tout)

        with gr.TabItem("Upscale & BG Removal & GIF"):
            uimg = gr.Image(type="pil", label="Upload image")
            scale = gr.Slider(label="Upscale factor", value=2, minimum=1, maximum=4, step=1)
            up_btn = gr.Button("Upscale Image")
            up_out = gr.Image()
            up_btn.click(upscale_image, inputs=[uimg, scale], outputs=up_out)

            rm_btn = gr.Button("Remove White Background (fast)")
            rm_out = gr.Image()
            rm_btn.click(remove_background, inputs=uimg, outputs=rm_out)

            gif_btn = gr.Button("Make GIF (takes uploads array)")
            gallery = gr.Gallery(label="Upload multiple images for GIF").style(grid=[2], height="200px")
            gif_out = gr.Video()
            # For GIF: we will accept the gallery images when user provides them and produce a gif
            def make_gif(imgs):
                if not imgs:
                    return None
                return images_to_gif(imgs, duration=500)
            gif_btn.click(make_gif, inputs=gallery, outputs=gif_out)

        with gr.TabItem("Chatbot"):
            chat_in = gr.Textbox(label="Message")
            chat_btn = gr.Button("Send")
            chat_out = gr.Textbox(label="AI Reply")
            chat_btn.click(chat_reply, inputs=chat_in, outputs=chat_out)

    gr.Markdown("<small>Made with ❤️ — HBfast.ai · Hosted on HuggingFace Spaces</small>")

if __name__ == '__main__':
    demo.launch()