# HBfast.ai — HuggingFace Space
This Space contains a simple collection of free AI tools: image generator, text→30s video, image→5s video, upscaler, background remover, GIF maker, and a small chatbot.
\n## Notes
- Large models like Stable Diffusion may take time to load or may require GPU. If loading fails use smaller community models.
- The upscaler is a simple PIL resize (not ML super-resolution). Replace with an ML upscaler if needed.
\n## How to use
1. Upload these files to your HuggingFace Space repository.
2. Click **Restart Space**.
3. Open the Space URL to use the tools.
\n## Files included
- app.py\n- index.html\n- style.css\n- script.js\n- logo.svg\n- favicon.svg\n- README.md
